import hashlib
import json
import re
import secrets
import socket
import threading
import time
import uuid
from collections.abc import Iterable, Iterator, Sequence, Set
from contextlib import AbstractContextManager, contextmanager
from dataclasses import dataclass, field
from email.message import Message
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Literal, TypedDict, overload
from urllib.parse import parse_qs, unquote, unquote_plus, urlsplit

from .http import request
from .manifest import fields, parse_json
from .values import PERSONAS, FixtureSession, GatewaySession, UserPersona

API = "/api/apps/v1"
MAX_UPLOAD = 20 * 1024**2
RESULT = b"name,value\nfixture,42\n"
PERSONA_COOKIE = "hp-fixture-user"
PERSONA_QUERY = "fixture_user"
PLATFORM_COOKIE_PREFIX = "home_platform"
HOP_BY_HOP = frozenset(
    {
        "connection",
        "keep-alive",
        "proxy-connection",
        "proxy-authenticate",
        "proxy-authorization",
        "te",
        "trailer",
        "transfer-encoding",
        "upgrade",
    }
)
RESERVED_HEADERS = frozenset(
    {
        "host",
        "forwarded",
        "x-real-ip",
        "content-length",
        "cookie",
        "expect",
        "x-api-token",
        "x-service-identity-token",
    }
)
RESERVED_HEADER_PREFIXES = ("tailscale-", "x-platform-", "x-forwarded-")
FIXTURE_HEADER_PREFIX = "x-fixture-"
RUN_ADVANCES = {"RUNNING": {"QUEUED"}, "COMPLETED": {"QUEUED", "RUNNING"}}


class Task(TypedDict):
    index: int
    status: str


class FixtureRun(TypedDict):
    id: str
    installation_id: str
    status: str
    tasks: list[Task]
    app: str
    owner: str


@dataclass(frozen=True)
class OwnedInput:
    app: str
    owner: str
    installation: str
    content: bytes


@dataclass
class FixtureState:
    app_id: str
    workload_ids: tuple[str, ...] = ("csv-summary",)
    credential: str = field(
        default_factory=lambda: secrets.token_urlsafe(32), repr=False
    )
    assertions: dict[str, tuple[UserPersona, float]] = field(
        default_factory=dict, repr=False
    )
    inputs: dict[str, OwnedInput] = field(default_factory=dict)
    deleted: set[str] = field(default_factory=set)
    runs: dict[str, FixtureRun] = field(default_factory=dict)
    replays: dict[tuple[str, str, str], tuple[dict[str, object], str]] = field(
        default_factory=dict
    )
    scenarios: dict[str, bool] = field(default_factory=dict)
    app_origin: str | None = None
    base_path: str = "/apps/fixture"
    run_seconds: float | None = None
    lock: threading.RLock = field(default_factory=threading.RLock, repr=False)

    @property
    def installations(self) -> dict[str, str]:
        return {
            str(uuid.uuid5(uuid.NAMESPACE_URL, self.app_id + "/" + name)): name
            for name in self.workload_ids
        }

    def assertion(self, selector: str) -> str:
        persona = next((p for p in PERSONAS if p.selector == selector.lower()), None)
        if persona is None:
            raise Refusal(400, "Unknown fictional persona")
        token = secrets.token_urlsafe(32)
        now = time.monotonic()
        with self.lock:
            self.assertions = {
                key: val for key, val in self.assertions.items() if val[1] > now
            }
            if len(self.assertions) >= 1000:
                raise Refusal(503, "Fixture assertion limit")
            self.assertions[token] = (persona, now + 120)
        return token

    def authenticate(self, headers: Message) -> UserPersona:
        if headers.get("Authorization") != "Bearer " + self.credential:
            raise Refusal(401, "Invalid fixture credential")
        item = self.assertions.get(headers.get("X-Platform-User-Context", ""))
        if item is None or item[1] <= time.monotonic():
            raise Refusal(401, "Invalid fixture context")
        if self.scenarios.get("denied"):
            raise Refusal(403, "Fixture grant denied")
        if self.scenarios.get("unavailable"):
            raise Refusal(503, "Fixture unavailable")
        return item[0]

    def schedule(self, run_id: str) -> None:
        if self.run_seconds is None:
            return
        for fraction, status in ((0.5, "RUNNING"), (1.0, "COMPLETED")):
            timer = threading.Timer(
                self.run_seconds * fraction, self.advance, (run_id, status)
            )
            timer.daemon = True
            timer.start()

    def advance(self, run_id: str, status: str) -> None:
        with self.lock:
            run = self.runs.get(run_id)
            if (
                run is not None
                and not self.scenarios.get("hold_runs")
                and run["status"] in RUN_ADVANCES[status]
            ):
                run["status"] = status
                run["tasks"] = [{"index": 0, "status": status}]

    def owned_run(self, run_id: str, owner: str) -> FixtureRun:
        run = self.runs.get(run_id)
        if not run or run["owner"] != owner or run["app"] != self.app_id:
            raise Refusal(404, "Run not found")
        return run


class Refusal(Exception):
    def __init__(self, status: int, detail: str) -> None:
        self.status, self.detail = status, detail


def text_field(value: object) -> str:
    if not isinstance(value, str):
        raise Refusal(422, "Invalid request fields")
    return value


def run_view(run: FixtureRun) -> dict[str, object]:
    return {
        "id": run["id"],
        "installation_id": run["installation_id"],
        "status": run["status"],
        "tasks": run["tasks"],
    }


def input_view(identifier: str, item: OwnedInput) -> dict[str, object]:
    return {
        "id": identifier,
        "size_bytes": len(item.content),
        "sha256": hashlib.sha256(item.content).hexdigest(),
    }


def logical_files(persona: UserPersona) -> dict[str, bytes]:
    return {
        "Home/Inputs/data.csv": f"name,value\n{persona.display_name},1\n".encode(),
        "Shared/Inputs/data.csv": b"name,value\nshared,2\n",
    }


def reserved_cookie(name: str) -> bool:
    name = name.lower()
    for prefix in ("__host-", "__secure-"):
        if name.startswith(prefix):
            name = name[len(prefix) :]
    return name.startswith(PLATFORM_COOKIE_PREFIX) or name == PERSONA_COOKIE


def request_cookies(values: list[str]) -> tuple[str | None, str | None]:
    persona = None
    kept = []
    for part in (item.strip() for value in values for item in value.split(";")):
        name, separator, value = part.partition("=")
        if not separator:
            continue
        if name.strip() == PERSONA_COOKIE and persona is None:
            persona = value.strip()
        if not reserved_cookie(name.strip()):
            kept.append(part)
    return persona, "; ".join(kept) or None


def hop_headers(connection: Iterable[str]) -> frozenset[str]:
    return HOP_BY_HOP | {
        part.strip().lower() for value in connection for part in value.split(",")
    }


def forward_headers(headers: Message) -> dict[str, str]:
    blocked = hop_headers(headers.get_all("Connection", [])) | RESERVED_HEADERS
    return {
        key: value
        for key, value in headers.items()
        if key.lower() not in blocked
        and not key.lower().startswith(
            (*RESERVED_HEADER_PREFIXES, FIXTURE_HEADER_PREFIX)
        )
    }


def forwarded_query(query: str) -> str:
    return "&".join(
        part
        for part in query.split("&")
        if unquote_plus(part.partition("=")[0]) != PERSONA_QUERY
    )


def rewrite_location(value: str, backend: str, route: str) -> str:
    try:
        parsed, origin = urlsplit(value), urlsplit(backend)
        if (
            parsed.scheme == origin.scheme
            and parsed.hostname == origin.hostname
            and parsed.port == origin.port
            and parsed.username is None
        ):
            return (
                route
                + (parsed.path or "/")
                + ("?" + parsed.query if parsed.query else "")
                + ("#" + parsed.fragment if parsed.fragment else "")
            )
    except ValueError:
        pass
    return value


def cookie_violation(value: str, route: str) -> str | None:
    parts = [part.strip() for part in value.split(";")]
    name, separator, cookie_value = parts[0].partition("=")
    if len(cookie_value) >= 2 and cookie_value[0] == cookie_value[-1] == '"':
        cookie_value = cookie_value[1:-1]
    if (
        not separator
        or not re.fullmatch(r"[!#$%&'*+.^_`|~0-9A-Za-z-]+", name)
        or reserved_cookie(name)
        or any(c in cookie_value for c in ',;\\" \t\r\n')
        or any(ord(c) < 0x21 or ord(c) > 0x7E for c in cookie_value)
    ):
        return "Reserved or invalid application cookie"
    paths = []
    for part in parts[1:]:
        attribute, separator, attribute_value = part.partition("=")
        if attribute.strip().lower() == "domain":
            return "Application cookie must not set Domain"
        if attribute.strip().lower() == "path":
            if not separator:
                return "Invalid application cookie Path"
            paths.append(attribute_value.strip())
    if len(paths) != 1:
        return "Application cookie requires one explicit Path"
    path = paths[0]
    if (
        not (path == route or path.startswith(route + "/"))
        or any(character in path for character in '%?#\\"')
        or any(part in {".", ".."} for part in path.split("/"))
        or "//" in path
    ):
        return "Application cookie Path is outside its route"
    return None


def ambiguous_suffix(suffix: str) -> bool:
    decoded = unquote(suffix)
    return (
        "\\" in decoded
        or any(part in {".", ".."} for part in decoded.split("/"))
        or any(token in suffix.lower() for token in ("%2f", "%5c", "%00"))
    )


Scope = Literal["api", "control", "gateway"]


def handler(state: FixtureState, scope: Scope) -> type[BaseHTTPRequestHandler]:
    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def setup(self) -> None:
            super().setup()
            self.connection.settimeout(3)

        def log_message(self, *_: object) -> None:
            pass

        def send(
            self,
            status: int,
            value: object = None,
            headers: dict[str, str] | None = None,
        ) -> None:
            raw = (
                value
                if isinstance(value, bytes)
                else json.dumps(value).encode()
                if value is not None
                else b""
            )
            self.send_response(status)
            self.send_header("Content-Length", str(len(raw)))
            if "Content-Type" not in (headers or {}):
                self.send_header(
                    "Content-Type",
                    "application/octet-stream"
                    if isinstance(value, bytes)
                    else "application/json",
                )
            self.send_header("Cache-Control", "no-store")
            self.send_header("Connection", "close")
            for key, val in (headers or {}).items():
                self.send_header(key, val)
            self.end_headers()
            if raw and self.command != "HEAD":
                self.wfile.write(raw)
            self.close_connection = True

        def body(self, maximum: int = 64 * 1024) -> bytes:
            sizes = self.headers.get_all("Content-Length", [])
            if (
                len(sizes) != 1
                or not sizes[0].isascii()
                or not sizes[0].isdigit()
                or self.headers.get("Transfer-Encoding")
            ):
                raise Refusal(400, "One Content-Length is required")
            return self.exact(int(sizes[0]), maximum)

        def exact(self, size: int, maximum: int) -> bytes:
            if size > maximum:
                raise Refusal(413, "Fixture body exceeds bound")
            raw = self.rfile.read(size)
            if len(raw) != size:
                raise Refusal(400, "Incomplete body")
            return raw

        def chunked(self, maximum: int) -> bytes:
            parts, total = [], 0
            while True:
                line = self.rfile.readline(1024)
                digits = line.removesuffix(b"\r\n").split(b";", 1)[0].strip()
                if not line.endswith(b"\r\n") or not re.fullmatch(
                    rb"[0-9A-Fa-f]{1,8}", digits
                ):
                    raise Refusal(400, "Invalid chunked body")
                size = int(digits, 16)
                if not size:
                    break
                total += size
                if total > maximum:
                    raise Refusal(413, "Fixture body exceeds bound")
                chunk = self.exact(size + 2, size + 2)
                if not chunk.endswith(b"\r\n"):
                    raise Refusal(400, "Invalid chunked body")
                parts.append(chunk[:-2])
            for _ in range(64):
                line = self.rfile.readline(8192)
                if line == b"\r\n":
                    return b"".join(parts)
                if not line.endswith(b"\r\n"):
                    break
            raise Refusal(400, "Invalid chunked body")

        def forwarded_body(self) -> bytes | Iterator[bytes] | None:
            if self.headers.get_all("Transfer-Encoding"):
                return iter((self.chunked(MAX_UPLOAD),))
            sizes = {
                size.strip() for size in self.headers.get_all("Content-Length", [])
            }
            if not sizes:
                return None
            size = next(iter(sizes))
            if len(sizes) != 1 or not size.isascii() or not size.isdigit():
                raise Refusal(400, "Invalid Content-Length")
            return self.exact(int(size), MAX_UPLOAD)

        def json_body(
            self, required: Set[str], optional: Set[str] = frozenset()
        ) -> dict[str, object]:
            try:
                return fields(parse_json(self.body(), 64 * 1024), required, optional)
            except ValueError:
                raise Refusal(422, "Invalid request fields") from None

        def dispatch(self) -> None:
            try:
                if scope == "gateway":
                    self.gateway()
                elif scope == "control":
                    with state.lock:
                        self.control()
                else:
                    with state.lock:
                        self.api()
            except Refusal as error:
                self.send(error.status, {"detail": error.detail})
            except (ValueError, KeyError, TypeError):
                self.send(422, {"detail": "Invalid fixture request"})
            except (OSError, TimeoutError):
                self.close_connection = True

        do_GET = do_HEAD = do_POST = do_PUT = do_PATCH = do_DELETE = dispatch
        do_OPTIONS = dispatch

        def control(self) -> None:
            if self.command != "POST":
                raise Refusal(404, "Control not found")
            if self.path == "/assertion":
                data = self.json_body({"persona"})
                self.send(
                    200, {"assertion": state.assertion(text_field(data["persona"]))}
                )
            elif self.path == "/scenarios":
                data = self.json_body(
                    set(),
                    {
                        "lost_submit_response",
                        "incomplete_result",
                        "corrupt_bytes",
                        "denied",
                        "unavailable",
                        "changed_input",
                        "hold_runs",
                    },
                )
                scenarios = {k: v for k, v in data.items() if type(v) is bool}
                if len(scenarios) != len(data):
                    raise Refusal(422, "Scenario values must be boolean")
                state.scenarios.update(scenarios)
                self.send(200, {"ok": True})
            elif self.path == "/transition":
                data = self.json_body({"run_id", "status"})
                status = text_field(data["status"])
                if status not in {
                    "RUNNING",
                    "COMPLETED",
                    "FAILED",
                    "CANCELLED",
                }:
                    raise Refusal(422, "Invalid transition")
                run = state.runs.get(text_field(data["run_id"]))
                if run is None:
                    raise Refusal(404, "Run not found")
                if run["status"] not in {"QUEUED", "RUNNING"}:
                    raise Refusal(409, "Run is terminal")
                run["status"] = status
                run["tasks"] = [{"index": 0, "status": status}]
                self.send(200, run_view(run))
            else:
                raise Refusal(404, "Control not found")

        def gateway(self) -> None:
            app_origin = state.app_origin
            if app_origin is None:
                raise Refusal(503, "No app configured")
            parsed = urlsplit(self.path)
            if parsed.path == "/":
                self.send(
                    200,
                    (
                        f'<a href="{state.base_path}/?fixture_user=alex">Alex</a> '
                        f'<a href="{state.base_path}/?fixture_user=sam">Sam</a>'
                    ).encode(),
                    {"Content-Type": "text/html"},
                )
                return
            if parsed.path == state.base_path:
                query = "?" + parsed.query if parsed.query else ""
                self.send(308, headers={"Location": state.base_path + "/" + query})
                return
            if not parsed.path.startswith(state.base_path + "/"):
                raise Refusal(404, "Route not found")
            if ambiguous_suffix(parsed.path[len(state.base_path) :]):
                raise Refusal(400, "Invalid application path")
            selected, cookies = request_cookies(self.headers.get_all("Cookie", []))
            persona = (
                self.headers.get("X-Fixture-User")
                or parse_qs(parsed.query).get(PERSONA_QUERY, [selected or "alex"])[0]
            )
            headers = forward_headers(self.headers)
            if cookies:
                headers["Cookie"] = cookies
            headers["X-Platform-User-Context"] = state.assertion(persona)
            body = self.forwarded_body()
            query = forwarded_query(parsed.query)
            path = parsed.path[len(state.base_path) :] + ("?" + query if query else "")
            response = request(
                app_origin, path, headers=headers, method=self.command, body=body
            )
            hop = hop_headers(
                v for k, v in response.headers if k.lower() == "connection"
            )
            forwarded = []
            for key, val in response.headers:
                name = key.lower()
                if name == "clear-site-data":
                    raise Refusal(
                        502, "Application response attempts to clear platform data"
                    )
                if name == "set-cookie":
                    violation = cookie_violation(val, state.base_path)
                    if violation is not None:
                        raise Refusal(502, violation)
                if name in hop | {"content-length", "service-worker-allowed"}:
                    continue
                if name == "location":
                    val = rewrite_location(val, app_origin, state.base_path)
                forwarded.append((key, val))
            self.send_response(response.status)
            length = str(len(response.body))
            if self.command == "HEAD":
                length = response.header("content-length") or "0"
            self.send_header("Content-Length", length)
            self.send_header("Connection", "close")
            self.send_header(
                "Set-Cookie",
                f"{PERSONA_COOKIE}={persona.lower()}; Path={state.base_path}; "
                "HttpOnly; SameSite=Strict",
            )
            for key, val in forwarded:
                self.send_header(key, val)
            self.end_headers()
            if self.command != "HEAD":
                self.wfile.write(response.body)
            self.close_connection = True

        def api(self) -> None:
            persona = state.authenticate(self.headers)
            parsed = urlsplit(self.path)
            if not parsed.path.startswith(API + "/"):
                raise Refusal(404, "API route not found")
            path = parsed.path[len(API) :]
            parts = path.strip("/").split("/")
            method = self.command
            if path == "/user" and method == "GET":
                self.send(200, {"id": persona.id, "display_name": persona.display_name})
            elif path == "/workloads" and method == "GET":
                self.send(
                    200,
                    {
                        "active_release_sha256": "a" * 64,
                        "items": [
                            {
                                "id": key,
                                "release_sha256": "a" * 64,
                                "workload_id": val,
                                "inputs": ["data"],
                            }
                            for key, val in state.installations.items()
                        ],
                    },
                )
            elif path == "/files" and method == "GET":
                query = parse_qs(parsed.query)
                logical = query.get("path", ["Home"])[0]
                files = logical_files(persona)
                if logical not in {"Home", "Home/Inputs", "Shared", "Shared/Inputs"}:
                    raise Refusal(422, "Unknown logical directory")
                items: list[dict[str, object]]
                if logical in {"Home", "Shared"}:
                    items = [
                        {
                            "name": "Inputs",
                            "path": logical + "/Inputs",
                            "kind": "directory",
                            "size_bytes": None,
                        }
                    ]
                else:
                    items = [
                        {
                            "name": "data.csv",
                            "path": logical + "/data.csv",
                            "kind": "file",
                            "size_bytes": len(files[logical + "/data.csv"]),
                        }
                    ]
                self.send(200, {"items": self.page(items, parsed.query)})
            elif (
                len(parts) == 3
                and parts[0] == "workloads"
                and parts[2] in {"uploads", "file-handles"}
                and method == "POST"
            ):
                installation = parts[1]
                if installation not in state.installations:
                    raise Refusal(404, "Installation not found")
                if parts[2] == "uploads":
                    if self.headers.get_content_type() != "application/octet-stream":
                        raise Refusal(415, "Raw octet-stream body required")
                    content: bytes | None = self.body(MAX_UPLOAD)
                    if not content:
                        raise Refusal(422, "Nonempty upload required")
                else:
                    data = self.json_body({"path"})
                    content = logical_files(persona).get(text_field(data["path"]))
                    if content is None:
                        raise Refusal(404, "Logical file not found")
                own = [
                    i
                    for k, i in state.inputs.items()
                    if k not in state.deleted
                    and i.app == state.app_id
                    and i.owner == persona.id
                ]
                if (
                    len(own) >= 100
                    or sum(len(i.content) for i in own) + len(content) > 200 * 1024**2
                    or sum(
                        len(i.content)
                        for k, i in state.inputs.items()
                        if k not in state.deleted
                    )
                    + len(content)
                    > 1024**3
                ):
                    raise Refusal(413, "Fixture input quota")
                identifier = str(uuid.uuid4())
                created = OwnedInput(state.app_id, persona.id, installation, content)
                state.inputs[identifier] = created
                self.send(201, input_view(identifier, created))
            elif len(parts) == 2 and parts[0] == "inputs" and method == "DELETE":
                item = state.inputs.get(parts[1])
                if item is None or item.owner != persona.id or item.app != state.app_id:
                    raise Refusal(404, "Input not found")
                state.deleted.add(parts[1])
                state.inputs[parts[1]] = OwnedInput(
                    item.app, item.owner, item.installation, b""
                )
                self.send(204)
            elif path == "/runs" and method == "POST":
                data = self.json_body({"installation_id", "inputs"})
                key = self.headers.get("Idempotency-Key", "")
                if not re.fullmatch(r"[A-Za-z0-9._:-]{1,128}", key):
                    raise Refusal(422, "Invalid idempotency key")
                replay_key = (state.app_id, persona.id, key)
                previous = state.replays.get(replay_key)
                if previous:
                    if previous[0] != data:
                        raise Refusal(409, "Conflicting idempotency body")
                    self.send(200, run_view(state.runs[previous[1]]))
                    return
                installation = text_field(data["installation_id"])
                if installation not in state.installations:
                    raise Refusal(404, "Installation not found")
                if not isinstance(data["inputs"], dict) or set(data["inputs"]) != {
                    "data"
                }:
                    raise Refusal(422, "Exact declared inputs required")
                item = state.inputs.get(data["inputs"]["data"])
                if (
                    item is None
                    or item.owner != persona.id
                    or item.app != state.app_id
                    or item.installation != installation
                    or data["inputs"]["data"] in state.deleted
                ):
                    raise Refusal(404, "Input not found")
                if state.scenarios.get("changed_input"):
                    raise Refusal(409, "Input changed after selection")
                active = [
                    r
                    for r in state.runs.values()
                    if r["status"] in {"QUEUED", "RUNNING"}
                ]
                if (
                    len(active) >= 4
                    or len([r for r in active if r["owner"] == persona.id]) >= 2
                ):
                    raise Refusal(409, "Fixture run capacity")
                identifier = str(uuid.uuid4())
                run: FixtureRun = {
                    "id": identifier,
                    "installation_id": installation,
                    "status": "QUEUED",
                    "tasks": [{"index": 0, "status": "QUEUED"}],
                    "app": state.app_id,
                    "owner": persona.id,
                }
                state.runs[identifier] = run
                state.replays[replay_key] = (data, identifier)
                state.schedule(identifier)
                if state.scenarios.pop("lost_submit_response", False):
                    self.connection.shutdown(socket.SHUT_RDWR)
                    self.close_connection = True
                    return
                self.send(201, run_view(run))
            elif path == "/runs" and method == "GET":
                self.send(
                    200,
                    {
                        "items": self.page(
                            [
                                run_view(r)
                                for r in state.runs.values()
                                if r["owner"] == persona.id and r["app"] == state.app_id
                            ],
                            parsed.query,
                        )
                    },
                )
            elif parts[0] == "runs" and len(parts) >= 2:
                run = state.owned_run(parts[1], persona.id)
                if len(parts) == 2 and method == "GET":
                    self.send(200, run_view(run))
                elif len(parts) == 3 and parts[2] == "cancel" and method == "POST":
                    if run["status"] in {"QUEUED", "RUNNING"}:
                        run["status"] = "CANCELLED"
                        run["tasks"] = [{"index": 0, "status": "CANCELLED"}]
                    self.send(200, run_view(run))
                elif parts[2:] == ["results"] and method == "GET":
                    self.result_ready(run)
                    digest = hashlib.sha256(RESULT).hexdigest()
                    self.send(
                        200,
                        {
                            "outputs": [
                                {
                                    "index": 0,
                                    "name": "report.csv",
                                    "size_bytes": len(RESULT),
                                    "sha256": digest,
                                    "download_url": API
                                    + "/runs/"
                                    + run["id"]
                                    + "/results/0/report.csv?sha256="
                                    + digest,
                                }
                            ]
                        },
                    )
                elif parts[2:] == ["results", "0", "report.csv"] and method == "GET":
                    self.result_ready(run)
                    if parse_qs(parsed.query).get("sha256") != [
                        hashlib.sha256(RESULT).hexdigest()
                    ]:
                        raise Refusal(409, "Result digest mismatch")
                    self.send(
                        200,
                        RESULT.replace(b"42", b"00")
                        if state.scenarios.get("corrupt_bytes")
                        else RESULT,
                    )
                else:
                    raise Refusal(404, "Run route not found")
            else:
                raise Refusal(404, "API route not found")

        def result_ready(self, run: FixtureRun) -> None:
            if run["status"] != "COMPLETED" or state.scenarios.get("incomplete_result"):
                raise Refusal(409, "Complete results unavailable")

        def page(self, items: Sequence[object], query: str) -> Sequence[object]:
            values = parse_qs(query)
            limit, offset = (
                int(values.get("limit", ["100"])[0]),
                int(values.get("offset", ["0"])[0]),
            )
            if not 1 <= limit <= 100 or not 0 <= offset <= 100000:
                raise Refusal(422, "Invalid pagination")
            return items[offset : offset + limit]

    return Handler


def serve(
    state: FixtureState, scope: Scope, host: str = "127.0.0.1", port: int = 0
) -> ThreadingHTTPServer:
    server = ThreadingHTTPServer((host, port), handler(state, scope))
    server.daemon_threads = True
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server


@overload
def fixture_session(
    app_id: str = ...,
    workload_ids: Sequence[str] = ...,
    *,
    app_origin: str,
    base_path: str = ...,
    run_seconds: float | None = ...,
) -> AbstractContextManager[GatewaySession]: ...


@overload
def fixture_session(
    app_id: str = ...,
    workload_ids: Sequence[str] = ...,
    *,
    app_origin: None = ...,
    base_path: str = ...,
    run_seconds: float | None = ...,
) -> AbstractContextManager[FixtureSession]: ...


def fixture_session(
    app_id: str = "example-csv-report",
    workload_ids: Sequence[str] = ("csv-summary",),
    *,
    app_origin: str | None = None,
    base_path: str = "/apps/fixture",
    run_seconds: float | None = None,
) -> AbstractContextManager[FixtureSession]:
    return running_session(app_id, workload_ids, app_origin, base_path, run_seconds)


@contextmanager
def running_session(
    app_id: str,
    workload_ids: Sequence[str],
    app_origin: str | None,
    base_path: str,
    run_seconds: float | None,
) -> Iterator[FixtureSession]:
    with TemporaryDirectory(prefix="hp-fixture-") as directory:
        root = Path(directory)
        root.chmod(0o700)
        credential = root / "app-credential"
        state_dir = root / "state"
        state_dir.mkdir(mode=0o700)
        state = FixtureState(
            app_id,
            tuple(workload_ids),
            app_origin=app_origin,
            base_path=base_path,
            run_seconds=run_seconds,
        )
        credential.write_text(state.credential, encoding="ascii")
        credential.chmod(0o600)
        api, control = serve(state, "api"), serve(state, "control")
        gateway = serve(state, "gateway") if app_origin else None
        origins = (
            f"http://127.0.0.1:{api.server_port}",
            f"http://127.0.0.1:{control.server_port}",
        )
        session = (
            GatewaySession(
                *origins,
                credential,
                state_dir,
                f"http://127.0.0.1:{gateway.server_port}",
            )
            if gateway
            else FixtureSession(*origins, credential, state_dir)
        )
        try:
            yield session
        finally:
            for server in (gateway, control, api):
                if server:
                    server.shutdown()
                    server.server_close()


def container_main() -> None:
    import os

    state = FixtureState(
        os.environ["APP_ID"],
        tuple(json.loads(os.environ["FIXTURE_WORKLOAD_IDS"])),
        app_origin=os.environ["FIXTURE_APP_ORIGIN"],
        base_path=os.environ["APP_BASE_PATH"],
    )
    root = Path("/credentials")
    credential = root / "app-credential"
    credential.write_text(state.credential, encoding="ascii")
    credential.chmod(0o400)
    serve(state, "api", "0.0.0.0", 8081)
    serve(state, "gateway", "0.0.0.0", 8082)
    control = serve(state, "control", "127.0.0.1", 8083)
    try:
        while True:
            time.sleep(1)
    finally:
        control.shutdown()


if __name__ == "__main__":
    container_main()
