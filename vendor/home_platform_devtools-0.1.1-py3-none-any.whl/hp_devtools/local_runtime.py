import hashlib
import importlib.resources
import json
import os
import secrets
import subprocess
import time
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Literal

from . import __version__
from .fixture import fixture_session
from .manifest import Manifest
from .values import CheckReport, Finding, GatewaySession, LocalImage, RunningApp

LABEL = "io.home-platform.devtools.session"
DEV_RUN_SECONDS = 2.0
BASE_IMAGE = (
    "python:3.11-slim"
    "@sha256:e88e9763f943ec1834f992a4b51e0f24500486803e8bc534e5767af9ea65f6ce"
)


def docker(*argv: str) -> str:
    result = subprocess.run(
        ["docker", *argv], capture_output=True, text=True, timeout=180
    )
    if result.returncode:
        raise RuntimeError(
            "Docker operation failed; check Docker availability and the local image"
        )
    return result.stdout.strip()


class OwnedDocker:
    def __init__(self) -> None:
        self.owner = secrets.token_hex(12)
        self.resources: list[tuple[str, str]] = []

    def create(self, kind: str, *args: str) -> str:
        identifier = docker(kind, "create", "--label", LABEL + "=" + self.owner, *args)
        self.resources.append((kind, identifier))
        return identifier

    def container(self, name: str, *args: str) -> str:
        identifier = docker(
            "create",
            "--name",
            name,
            "--label",
            LABEL + "=" + self.owner,
            "--user",
            "10001:10001",
            "--read-only",
            "--cap-drop",
            "ALL",
            "--security-opt",
            "no-new-privileges",
            "--cpus",
            "0.5",
            "--memory",
            "256m",
            "--pids-limit",
            "64",
            "--tmpfs",
            "/tmp:rw,noexec,nosuid,size=16777216",
            *args,
        )
        self.resources.append(("container", identifier))
        return identifier

    def close(self) -> None:
        failures = []
        for kind, identifier in reversed(self.resources):
            try:
                item = json.loads(docker(kind, "inspect", identifier))[0]
                labels = (
                    item.get("Labels")
                    if kind != "container"
                    else item["Config"].get("Labels")
                )
                if (labels or {}).get(LABEL) == self.owner:
                    docker(
                        kind,
                        "rm",
                        *(["--force"] if kind == "container" else []),
                        identifier,
                    )
                else:
                    failures.append(identifier)
            except (RuntimeError, ValueError, KeyError):
                failures.append(identifier)
        if failures:
            raise RuntimeError("Owned resource cleanup could not be verified")


def build_fixture_image(owner: str) -> tuple[str, str]:
    package = importlib.resources.files("hp_devtools")
    with TemporaryDirectory(prefix="hp-fixture-image-") as directory:
        root = Path(directory)
        dest = root / "hp_devtools"
        dest.mkdir()
        for source in package.iterdir():
            if source.name.endswith(".py"):
                (dest / source.name).write_bytes(source.read_bytes())
        (root / "Dockerfile").write_text(
            f"FROM {BASE_IMAGE}\n"
            "RUN mkdir /credentials /data && chown 10001:10001 /credentials /data\n"
            "COPY hp_devtools /opt/hp_devtools\n"
            "ENV PYTHONPATH=/opt PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1\n"
            "USER 10001:10001\n"
            'CMD ["python", "-m", "hp_devtools.fixture"]\n',
            encoding="utf-8",
        )
        tag = "hp-devtools-fixture:" + owner
        docker("build", "--label", LABEL + "=" + owner, "-t", tag, str(root))
        return tag, docker("image", "inspect", "--format", "{{.Id}}", tag)


@dataclass(frozen=True)
class ImageSession:
    target: RunningApp
    fixture_id: str
    app_id: str


def check_local_session(
    raw: bytes, session: ImageSession, *, template: bool = False
) -> CheckReport:
    payload = json.dumps(
        {
            "manifest": raw.decode("utf-8"),
            "template": template,
            "target": {
                "direct_origin": session.target.direct_origin,
                "routed_origin": session.target.routed_origin,
                "base_path": session.target.base_path,
                "routed_headers": dict(session.target.routed_headers),
            },
        }
    ).encode()
    result = subprocess.run(
        [
            "docker",
            "exec",
            "--interactive",
            session.fixture_id,
            "python",
            "-m",
            "hp_devtools.container_check",
        ],
        input=payload,
        capture_output=True,
        timeout=90,
    )
    if result.returncode:
        raise RuntimeError("Disposable fixture checker failed")
    from .checks import CHECK_NAMES
    from .manifest import parse_json

    value = parse_json(result.stdout, 64 * 1024)
    mode: Literal["template", "final"] = "template" if template else "final"
    findings = value.get("findings") if isinstance(value, dict) else None
    if (
        not isinstance(value, dict)
        or value.get("checker_version") != __version__
        or value.get("contract_version") != 1
        or value.get("mode") != mode
        or value.get("manifest_sha256") != hashlib.sha256(raw).hexdigest()
        or not isinstance(findings, list)
        or not all(
            isinstance(v, dict)
            and type(v.get("passed")) is bool
            and isinstance(v.get("detail"), str)
            for v in findings
        )
        or [v["check"] for v in findings] != list(CHECK_NAMES)
    ):
        raise RuntimeError("Invalid disposable checker report")
    return CheckReport(
        __version__,
        1,
        mode,
        value["manifest_sha256"],
        tuple(Finding(v["check"], v["passed"], v["detail"]) for v in findings),
    )


@contextmanager
def local_image(target: LocalImage, manifest: Manifest) -> Iterator[ImageSession]:
    if (
        not target.image
        or target.image.startswith("-")
        or len(target.image) > 1024
        or any(ord(c) <= 32 or ord(c) >= 127 for c in target.image)
    ):
        raise ValueError("Invalid local image")
    docker("image", "inspect", target.image)
    owned = OwnedDocker()
    fixture_image_id = None
    try:
        fixture_image, fixture_image_id = build_fixture_image(owned.owner)
        network = owned.create("network", "--internal", "hp-dev-" + owned.owner)
        credentials = owned.create("volume", "hp-credentials-" + owned.owner)
        state = owned.create("volume", "hp-state-" + owned.owner)
        app_name, fixture_name = "hp-app-" + owned.owner, "hp-fixture-" + owned.owner
        base = "/apps/" + manifest["app_id"]
        port = manifest["runtime"]["port"]
        fixture = owned.container(
            fixture_name,
            "--network",
            network,
            "--mount",
            "type=volume,source=" + credentials + ",target=/credentials",
            "--mount",
            "type=volume,source=" + state + ",target=/data",
            "--env",
            "APP_ID=" + manifest["app_id"],
            "--env",
            "APP_BASE_PATH=" + base,
            "--env",
            "FIXTURE_APP_ORIGIN=http://" + app_name + ":" + str(port),
            "--env",
            "FIXTURE_WORKLOAD_IDS="
            + json.dumps([w["id"] for w in manifest.get("workloads", [])]),
            fixture_image,
        )
        docker("start", fixture)
        for _ in range(30):
            item = json.loads(docker("container", "inspect", fixture))[0]
            if not item["State"]["Running"]:
                raise RuntimeError("Fixture stopped before app launch")
            probe = subprocess.run(
                [
                    "docker",
                    "exec",
                    fixture,
                    "test",
                    "-s",
                    "/credentials/app-credential",
                ],
                capture_output=True,
                timeout=5,
            )
            if probe.returncode == 0:
                break
            time.sleep(0.1)
        else:
            raise RuntimeError("Fixture credential not ready")
        app = owned.container(
            app_name,
            "--network",
            network,
            "--mount",
            "type=volume,source=" + credentials + ",target=/run/secrets,readonly",
            "--mount",
            "type=volume,source=" + state + ",target=/data",
            "--env",
            "APP_ID=" + manifest["app_id"],
            "--env",
            "APP_BASE_PATH=" + base,
            "--env",
            "APP_STATE_DIR=/data",
            "--env",
            "APP_CREDENTIAL_FILE=/run/secrets/app-credential",
            "--env",
            "PLATFORM_API_URL=http://" + fixture_name + ":8081/api/apps/v1",
            "--env",
            "TZ=UTC",
            target.image,
        )
        docker("start", app)
        direct, routed = (
            "http://" + app_name + ":" + str(port),
            "http://" + fixture_name + ":8082",
        )
        yield ImageSession(
            RunningApp(direct, routed, base, {"X-Fixture-User": "alex"}), fixture, app
        )
    finally:
        try:
            owned.close()
        finally:
            if fixture_image_id:
                docker("image", "rm", fixture_image_id)


@contextmanager
def process_app(
    manifest: Manifest, command: list[str]
) -> Iterator[tuple[GatewaySession, subprocess.Popen[bytes]]]:
    import socket

    if not command:
        raise ValueError("An explicit application command is required")
    with socket.socket() as reservation:
        reservation.bind(("127.0.0.1", 0))
        port = reservation.getsockname()[1]
    base = "/apps/" + manifest["app_id"]
    app_origin = f"http://127.0.0.1:{port}"
    with fixture_session(
        manifest["app_id"],
        [w["id"] for w in manifest.get("workloads", [])],
        app_origin=app_origin,
        base_path=base,
        run_seconds=DEV_RUN_SECONDS,
    ) as session:
        allowed = {
            "PATH",
            "VIRTUAL_ENV",
            "PYTHONPATH",
            "LANG",
            "LC_ALL",
            "LC_CTYPE",
            "TERM",
        }
        env = {k: v for k, v in os.environ.items() if k in allowed}
        env.update(
            APP_ID=manifest["app_id"],
            APP_BASE_PATH=base,
            APP_STATE_DIR=str(session.state_dir),
            APP_CREDENTIAL_FILE=str(session.credential_file),
            PLATFORM_API_URL=session.api_origin + "/api/apps/v1",
            APP_PORT=str(port),
            PORT=str(port),
            APP_HOST="127.0.0.1",
            HOST="127.0.0.1",
            TZ="UTC",
        )
        child = subprocess.Popen(command, env=env, start_new_session=True)
        try:
            yield session, child
        finally:
            import signal

            if child.poll() is None:
                os.killpg(child.pid, signal.SIGTERM)
                try:
                    child.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL)
                    child.wait(timeout=5)
