import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path

from . import __version__
from .checks import CHECK_NAMES, check_app, parse_target
from .local_runtime import check_local_session, local_image
from .manifest import MAX_MANIFEST_BYTES, parse_manifest
from .values import CheckReport, Finding, LocalImage


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Portable app checker. Local images use fictional identity."
    )
    parser.add_argument("--manifest", type=Path)
    parser.add_argument(
        "--template",
        nargs="?",
        const=True,
        default=False,
        help="Allow explicit build placeholders; optionally supply the manifest path",
    )
    target = parser.add_mutually_exclusive_group(required=True)
    target.add_argument("--target-stdin", action="store_true")
    target.add_argument("--image")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)
    path = args.manifest
    if isinstance(args.template, str):
        if path is not None:
            parser.error("Supply the manifest path once")
        path = Path(args.template)
    if path is None:
        parser.error("--manifest is required")
    if args.target_stdin and args.template:
        parser.error("Running targets require a final manifest")
    try:
        with path.open("rb") as source:
            raw = source.read(MAX_MANIFEST_BYTES + 1)
        manifest = parse_manifest(raw, template=bool(args.template))
        if args.target_stdin:
            running = parse_target(sys.stdin.buffer.read(64 * 1024 + 1))
            report = check_app(raw, running)
        else:
            if not args.template and args.image != manifest["image"]:
                raise ValueError("Final image must match the manifest digest reference")
            try:
                with local_image(LocalImage(args.image), manifest) as session:
                    report = check_local_session(
                        raw, session, template=bool(args.template)
                    )
            except (OSError, RuntimeError, ValueError, subprocess.SubprocessError):
                report = CheckReport(
                    __version__,
                    1,
                    "template" if args.template else "final",
                    hashlib.sha256(raw).hexdigest(),
                    tuple(
                        Finding(name, False, "Local fixture launch or cleanup failed")
                        for name in CHECK_NAMES
                    ),
                )
        if args.json:
            print(json.dumps(report.to_dict(), sort_keys=True, separators=(",", ":")))
        else:
            for finding in report.findings:
                print(
                    f"{'PASS' if finding.passed else 'FAIL'} {finding.check}: "
                    f"{finding.detail}"
                )
            if args.image:
                print(
                    "Local fictional fixture check. Managed authentication and "
                    "resource enforcement need separate preview acceptance."
                )
        return 0 if report.passed else 1
    except (OSError, ValueError):
        print("Invalid manifest or trusted target configuration", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
