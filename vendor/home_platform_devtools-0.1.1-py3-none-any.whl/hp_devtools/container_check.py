import json
import sys
import time

from .checks import check_app, parse_target
from .http import request
from .manifest import fields, parse_json, parse_manifest


def main() -> None:
    payload = fields(
        parse_json(sys.stdin.buffer.read(256 * 1024 + 1), 256 * 1024),
        {"manifest", "template", "target"},
    )
    if (
        not isinstance(payload["manifest"], str)
        or type(payload["template"]) is not bool
    ):
        raise ValueError("Invalid checker payload")
    raw = payload["manifest"].encode("utf-8")
    template = payload["template"]
    manifest = parse_manifest(raw, template=template)
    target = parse_target(json.dumps(payload["target"]).encode())
    for _ in range(30):
        try:
            request(target.direct_origin, manifest["runtime"]["health_path"])
            break
        except (OSError, ValueError):
            time.sleep(0.1)
    print(
        json.dumps(check_app(raw, target, template=template).to_dict(), sort_keys=True)
    )


if __name__ == "__main__":
    main()
