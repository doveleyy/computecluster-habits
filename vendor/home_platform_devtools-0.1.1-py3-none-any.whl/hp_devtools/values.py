from collections.abc import Mapping
from dataclasses import asdict, dataclass, field
from pathlib import Path
from types import MappingProxyType
from typing import Literal


@dataclass(frozen=True)
class UserPersona:
    selector: str
    id: str
    display_name: str


PERSONAS = (
    UserPersona("alex", "11111111-1111-4111-8111-111111111111", "Alex"),
    UserPersona("sam", "22222222-2222-4222-8222-222222222222", "Sam"),
)


@dataclass(frozen=True)
class FixtureSession:
    api_origin: str
    control_origin: str
    credential_file: Path
    state_dir: Path


@dataclass(frozen=True)
class GatewaySession(FixtureSession):
    gateway_origin: str


@dataclass(frozen=True)
class RunningApp:
    direct_origin: str
    routed_origin: str
    base_path: str
    routed_headers: Mapping[str, str] = field(repr=False)

    def __post_init__(self) -> None:
        object.__setattr__(
            self, "routed_headers", MappingProxyType(dict(self.routed_headers))
        )


@dataclass(frozen=True)
class LocalImage:
    image: str


@dataclass(frozen=True)
class Finding:
    check: str
    passed: bool
    detail: str


@dataclass(frozen=True)
class CheckReport:
    checker_version: str
    contract_version: int
    mode: Literal["template", "final"]
    manifest_sha256: str
    findings: tuple[Finding, ...]

    @property
    def passed(self) -> bool:
        return all(item.passed for item in self.findings)

    def to_dict(self) -> dict[str, object]:
        value = asdict(self)
        value["findings"] = list(value["findings"])
        return value
