import argparse
import signal
import sys
import time
from pathlib import Path

from .local_runtime import process_app
from .manifest import MAX_MANIFEST_BYTES, parse_manifest


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Standalone fictional app development")
    sub = parser.add_subparsers(dest="command", required=True)
    dev = sub.add_parser("dev")
    dev.add_argument("--definition", required=True, type=Path)
    dev.add_argument(
        "--command", dest="app_command", nargs=argparse.REMAINDER, required=True
    )
    args = parser.parse_args(argv)
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(128 + signal.SIGTERM))
    try:
        with args.definition.open("rb") as source:
            manifest = parse_manifest(
                source.read(MAX_MANIFEST_BYTES + 1), template=True
            )
        with process_app(manifest, args.app_command) as (session, child):
            print(
                "Fictional Alex/Sam gateway " + session.gateway_origin + "/", flush=True
            )
            print("Fixture controls " + session.control_origin + "/", flush=True)
            print(
                "Ctrl-C or SIGTERM stops this session and removes its temporary state.",
                flush=True,
            )
            while child.poll() is None:
                time.sleep(0.25)
            return child.returncode
    except KeyboardInterrupt:
        return 0
    except (OSError, ValueError):
        parser.error("Definition or explicit application command is invalid")


if __name__ == "__main__":
    raise SystemExit(main())
