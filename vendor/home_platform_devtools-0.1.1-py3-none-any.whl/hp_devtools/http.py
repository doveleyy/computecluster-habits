import http.client
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from urllib.parse import urlsplit

MAX_BODY = 1024 * 1024
TIMEOUT = 3


@dataclass(frozen=True)
class Response:
    status: int
    headers: tuple[tuple[str, str], ...]
    body: bytes

    def header(self, name: str) -> str:
        return next((v for k, v in self.headers if k.lower() == name.lower()), "")


def origin(value: object) -> str:
    if (
        not isinstance(value, str)
        or not value.isascii()
        or any(ord(c) <= 32 or ord(c) == 127 for c in value)
    ):
        raise ValueError("Invalid target origin")
    try:
        parsed = urlsplit(value)
        valid = (
            parsed.scheme in {"http", "https"}
            and parsed.hostname
            and parsed.port != 0
            and not parsed.username
            and not parsed.password
            and "@" not in parsed.netloc
            and parsed.path in {"", "/"}
            and not parsed.query
            and not parsed.fragment
            and "\\" not in value
        )
    except ValueError:
        valid = False
    if not valid:
        raise ValueError("Invalid target origin")
    return value.rstrip("/")


def request(
    target: str,
    path: str,
    *,
    headers: Mapping[str, str] | None = None,
    method: str = "GET",
    body: bytes | Iterable[bytes] | None = None,
    maximum: int = MAX_BODY,
) -> Response:
    parsed = urlsplit(target)
    if parsed.hostname is None:
        raise ValueError("Invalid target origin")
    cls = (
        http.client.HTTPSConnection
        if parsed.scheme == "https"
        else http.client.HTTPConnection
    )
    connection = cls(parsed.hostname, parsed.port, timeout=TIMEOUT)
    try:
        connection.request(method, path, body=body, headers=headers or {})
        response = connection.getresponse()
        raw = response.read(maximum + 1)
        if len(raw) > maximum:
            raise ValueError("Response exceeds size bound")
        return Response(response.status, tuple(response.getheaders()), raw)
    finally:
        connection.close()
