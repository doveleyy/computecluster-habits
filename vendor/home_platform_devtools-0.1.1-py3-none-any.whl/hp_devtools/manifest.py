import json
import re
from collections.abc import Set
from typing import NotRequired, TypedDict
from urllib.parse import unquote, urlsplit

MAX_MANIFEST_BYTES = 64 * 1024
IDENTIFIER = r"[a-z][a-z0-9]*(?:-[a-z0-9]+)*"
DIGEST = r"[0-9a-f]{64}"
PLACEHOLDERS = {
    "source_commit": {"${SOURCE_COMMIT}"},
    "image": {"${IMAGE}"},
    "sha256": {"${SHA256}"},
}


class Runtime(TypedDict):
    port: int
    health_path: str
    ready_path: str
    version_path: str


class State(TypedDict):
    sqlite_file: str


class Maintenance(TypedDict):
    name: str
    argv: list[str]
    interval_hours: int
    timeout_seconds: int


class Workload(TypedDict):
    id: str
    asset: str
    sha256: str
    entrypoint: str
    runtime: str


class Manifest(TypedDict):
    contract_version: int
    app_id: str
    source_commit: str
    image: str
    runtime: Runtime
    capabilities: list[str]
    state: NotRequired[State]
    secrets: NotRequired[list[str]]
    maintenance: NotRequired[list[Maintenance]]
    workloads: NotRequired[list[Workload]]


def unique_object(pairs: list[tuple[str, object]]) -> dict[str, object]:
    value = dict(pairs)
    if len(value) != len(pairs):
        raise ValueError("Duplicate JSON field")
    return value


def parse_json(raw: bytes, maximum: int) -> object:
    if len(raw) > maximum:
        raise ValueError("JSON exceeds size bound")
    try:
        return json.loads(
            raw,
            object_pairs_hook=unique_object,
            parse_constant=lambda _: (_ for _ in ()).throw(ValueError()),
        )
    except (UnicodeError, json.JSONDecodeError, RecursionError):
        raise ValueError("Invalid JSON") from None


def fields(
    value: object, required: Set[str], optional: Set[str] = frozenset()
) -> dict[str, object]:
    if (
        not isinstance(value, dict)
        or not required <= value.keys()
        or value.keys() - required - optional
    ):
        raise ValueError("Missing or unknown manifest fields")
    return value


def text(value: object, pattern: str, maximum: int = 256) -> str:
    if (
        not isinstance(value, str)
        or len(value) > maximum
        or not re.fullmatch(pattern, value)
    ):
        raise ValueError("Invalid manifest value")
    return value


def positive(value: object, maximum: int) -> int:
    if type(value) is not int or not 1 <= value <= maximum:
        raise ValueError("Invalid manifest integer")
    return value


def canonical_path(value: object) -> str:
    if not isinstance(value, str) or not value.startswith("/") or len(value) > 256:
        raise ValueError("Expected internal absolute path")
    parsed = urlsplit(value)
    decoded = unquote(value)
    if (
        not re.fullmatch(r"/(?:[A-Za-z0-9_.~-]+(?:/[A-Za-z0-9_.~-]+)*)?", value)
        or parsed.netloc
        or parsed.query
        or parsed.fragment
        or "\\" in decoded
        or any(ord(c) <= 32 or ord(c) >= 127 for c in value)
        or any(part in {".", ".."} for part in decoded.split("/"))
        or "//" in decoded
        or "%" in decoded
    ):
        raise ValueError("Unsafe internal path")
    return value


def basename(value: object) -> str:
    value = text(value, r"[A-Za-z0-9_.~-]+", 128)
    if value in {".", ".."}:
        raise ValueError("Unsafe basename")
    return value


def resolved(value: object, pattern: str, field: str, template: bool) -> str:
    if template and isinstance(value, str) and value in PLACEHOLDERS[field]:
        return value
    return text(value, pattern, 1024)


def entries(value: dict[str, object], key: str) -> list[object]:
    items = value.get(key, [])
    if not isinstance(items, list) or len(items) > 32:
        raise ValueError("Expected manifest list")
    return items


def unique_names(names: list[str]) -> None:
    if len(set(names)) != len(names):
        raise ValueError("Duplicate manifest entry")


def maintenance(value: object) -> Maintenance:
    entry = fields(value, {"name", "argv", "interval_hours", "timeout_seconds"})
    args = entry["argv"]
    if (
        not isinstance(args, list)
        or not 1 <= len(args) <= 32
        or not all(
            isinstance(a, str)
            and 0 < len(a) <= 256
            and not any(ord(c) < 32 or ord(c) == 127 for c in a)
            for a in args
        )
    ):
        raise ValueError("Invalid maintenance argv")
    return {
        "name": text(entry["name"], IDENTIFIER, 63),
        "argv": args,
        "interval_hours": positive(entry["interval_hours"], 8760),
        "timeout_seconds": positive(entry["timeout_seconds"], 86400),
    }


def workload(value: object, template: bool) -> Workload:
    entry = fields(value, {"id", "asset", "sha256", "entrypoint", "runtime"})
    identifier = text(entry["id"], IDENTIFIER, 63)
    asset = basename(entry["asset"])
    digest = resolved(entry["sha256"], DIGEST, "sha256", template)
    entrypoint = entry["entrypoint"]
    if (
        not isinstance(entrypoint, str)
        or not 1 <= len(entrypoint) <= 256
        or entrypoint.startswith("/")
    ):
        raise ValueError("Invalid workload entrypoint")
    canonical_path("/" + entrypoint)
    if entry["runtime"] != "scientific-python:1":
        raise ValueError("Unsupported workload runtime")
    return {
        "id": identifier,
        "asset": asset,
        "sha256": digest,
        "entrypoint": entrypoint,
        "runtime": "scientific-python:1",
    }


def parse_manifest(raw: bytes, *, template: bool = False) -> Manifest:
    value = fields(
        parse_json(raw, MAX_MANIFEST_BYTES),
        {
            "contract_version",
            "app_id",
            "source_commit",
            "image",
            "runtime",
            "capabilities",
        },
        {"state", "secrets", "maintenance", "workloads"},
    )
    if type(value["contract_version"]) is not int or value["contract_version"] != 1:
        raise ValueError("Unsupported contract version")
    app_id = text(value["app_id"], IDENTIFIER, 63)
    source_commit = resolved(
        value["source_commit"], r"[0-9a-f]{40}", "source_commit", template
    )
    image = resolved(
        value["image"],
        r"[a-z0-9]+(?:[.-][a-z0-9]+)*(?::[0-9]+)?/[a-z0-9]+(?:[._-][a-z0-9]+)*(?:/[a-z0-9]+(?:[._-][a-z0-9]+)*)*@sha256:"
        + DIGEST,
        "image",
        template,
    )
    if len(image) > 335:
        raise ValueError("Image reference exceeds bound")
    runtime = fields(
        value["runtime"], {"port", "health_path", "ready_path", "version_path"}
    )
    capabilities = value["capabilities"]
    if (
        not isinstance(capabilities, list)
        or not all(isinstance(c, str) for c in capabilities)
        or len(set(capabilities)) != len(capabilities)
        or "identity" not in capabilities
        or set(capabilities) - {"identity", "jobs", "files"}
    ):
        raise ValueError("Invalid capabilities")
    manifest: Manifest = {
        "contract_version": 1,
        "app_id": app_id,
        "source_commit": source_commit,
        "image": image,
        "runtime": {
            "port": positive(runtime["port"], 65535),
            "health_path": canonical_path(runtime["health_path"]),
            "ready_path": canonical_path(runtime["ready_path"]),
            "version_path": canonical_path(runtime["version_path"]),
        },
        "capabilities": capabilities,
    }
    if "state" in value:
        sqlite_file = fields(value["state"], {"sqlite_file"})["sqlite_file"]
        manifest["state"] = {"sqlite_file": basename(sqlite_file)}
    if "secrets" in value:
        secrets = [
            text(binding, r"[a-z][a-z0-9]*(?:[-_][a-z0-9]+)*", 63)
            for binding in entries(value, "secrets")
        ]
        normalized = [binding.replace("-", "_") for binding in secrets]
        if "app_credential" in normalized:
            raise ValueError("Reserved secret binding")
        if len(set(normalized)) != len(normalized):
            raise ValueError("Duplicate secret binding")
        manifest["secrets"] = secrets
    if "maintenance" in value:
        jobs = [maintenance(entry) for entry in entries(value, "maintenance")]
        unique_names([job["name"] for job in jobs])
        manifest["maintenance"] = jobs
    if "workloads" in value:
        if value["workloads"] and "jobs" not in capabilities:
            raise ValueError("Workloads require jobs")
        workloads = [workload(entry, template) for entry in entries(value, "workloads")]
        unique_names([item["id"] for item in workloads])
        manifest["workloads"] = workloads
    return manifest
