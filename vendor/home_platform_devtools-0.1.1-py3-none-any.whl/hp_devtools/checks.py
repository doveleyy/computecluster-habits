import hashlib
import re
import time
from collections.abc import Callable
from html.parser import HTMLParser
from urllib.parse import unquote, urljoin, urlsplit

from . import __version__
from .http import Response, origin, request
from .manifest import canonical_path, fields, parse_json, parse_manifest
from .values import CheckReport, Finding, RunningApp

CHECK_NAMES = (
    "health",
    "ready",
    "version",
    "direct-context",
    "forged-context",
    "routed-access",
    "base-path",
)
FORGED_PROBES = (
    ("context", {"X-Platform-User-Context": "forged-fixture-context"}),
    ("login", {"Tailscale-User-Login": "forged@example.invalid"}),
    (
        "context and login",
        {
            "X-Platform-User-Context": "forged-fixture-context",
            "Tailscale-User-Login": "forged@example.invalid",
        },
    ),
)


def parse_target(raw: bytes) -> RunningApp:
    value = fields(
        parse_json(raw, 64 * 1024),
        {"direct_origin", "routed_origin", "base_path", "routed_headers"},
    )
    direct = origin(value["direct_origin"])
    routed = origin(value["routed_origin"])
    base = canonical_path(value["base_path"])
    if base == "/" or base.endswith("/") or "%" in base:
        raise ValueError("Invalid external prefix")
    headers = value["routed_headers"]
    if not isinstance(headers, dict) or len(headers) > 32:
        raise ValueError("Invalid routed headers")
    for key, val in headers.items():
        if (
            not re.fullmatch(r"[A-Za-z0-9-]+", key)
            or key.lower()
            in {
                "host",
                "connection",
                "content-length",
                "transfer-encoding",
                "proxy-authorization",
            }
            or not isinstance(val, str)
            or not 0 < len(val) <= 8192
            or any(ord(c) < 32 or ord(c) >= 127 for c in val)
        ):
            raise ValueError("Invalid routed headers")
    return RunningApp(direct, routed, base, headers)


class References(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.urls: list[tuple[str, str, str]] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        for name, value in attrs:
            if name in {"src", "href", "action", "poster", "data"} and value:
                self.urls.append((tag, name, value))
            if name == "srcset" and value:
                self.urls.extend(
                    (tag, name, item.strip().split()[0])
                    for item in value.split(",")
                    if item.strip()
                )


def navigation_document(url: str, target: RunningApp, app_id: str) -> bool:
    if "\\" in url or "#" in url or any(ord(c) <= 32 or ord(c) >= 127 for c in url):
        return False
    source = urlsplit(url)
    resolved = urlsplit(urljoin(target.routed_origin + target.base_path + "/", url))
    return (
        source.path == "/platform/bar"
        and source.query == "app=" + app_id
        and resolved.scheme + "://" + resolved.netloc == target.routed_origin
        and resolved.username is None
        and resolved.password is None
    )


def confined(url: str, target: RunningApp) -> bool:
    if "\\" in url or any(ord(c) <= 32 or ord(c) >= 127 for c in url):
        return False
    parsed = urlsplit(urljoin(target.routed_origin + target.base_path + "/", url))
    if parsed.username or parsed.password or parsed.fragment:
        return False
    path = unquote(parsed.path)
    return (
        parsed.scheme + "://" + parsed.netloc == target.routed_origin
        and (path == target.base_path or path.startswith(target.base_path + "/"))
        and not any(part in {".", ".."} for part in path.split("/"))
        and "\\" not in path
        and "%" not in path
        and "//" not in path
    )


def check_app(raw: bytes, target: RunningApp, *, template: bool = False) -> CheckReport:
    manifest = parse_manifest(raw, template=template)
    findings = []
    runtime = manifest["runtime"]

    def run(name: str, probe: Callable[[], tuple[bool, str]]) -> None:
        try:
            passed, detail = probe()
        except Exception:
            passed, detail = False, "Probe failed or exceeded its response/time bound"
        findings.append(Finding(name, bool(passed), detail))

    def status(path: str) -> tuple[bool, str]:
        response = request(target.direct_origin, path)
        return response.status == 200, f"HTTP {response.status}; body is informational"

    def ready() -> tuple[bool, str]:
        for attempt in range(3):
            result = status(runtime["ready_path"])
            if result[0]:
                return result
            if attempt < 2:
                time.sleep(0.1)
        return result

    def version() -> tuple[bool, str]:
        response = request(target.direct_origin, runtime["version_path"])
        value = parse_json(response.body, 64 * 1024)
        passed = (
            response.status == 200
            and isinstance(value, dict)
            and value.get("service") == manifest["app_id"]
            and isinstance(value.get("version"), str)
            and bool(value["version"].strip())
        )
        return (
            passed,
            "Version service and nonempty version match"
            if passed
            else "Invalid version response",
        )

    def missing() -> tuple[bool, str]:
        response = request(target.direct_origin, "/")
        return (
            response.status in {401, 403},
            f"Direct request returned HTTP {response.status}",
        )

    def forged() -> tuple[bool, str]:
        results = [
            (
                name,
                request(
                    target.direct_origin,
                    "/",
                    headers={**headers, "X-Forwarded-Proto": "https"},
                ).status,
            )
            for name, headers in FORGED_PROBES
        ]
        return (
            all(status in {401, 403} for _, status in results),
            "Forged "
            + "; ".join(f"{name} returned HTTP {status}" for name, status in results),
        )

    routed_response: Response | None = None

    def routed() -> tuple[bool, str]:
        nonlocal routed_response
        routed_response = request(
            target.routed_origin,
            target.base_path + "/",
            headers=dict(target.routed_headers),
        )
        return (
            routed_response.status == 200,
            f"Routed request returned HTTP {routed_response.status}",
        )

    def base_path() -> tuple[bool, str]:
        bare = request(
            target.routed_origin, target.base_path, headers=dict(target.routed_headers)
        )
        location = bare.header("location")
        expected = urlsplit(urljoin(target.routed_origin + target.base_path, location))
        if (
            bare.status not in {301, 302, 303, 307, 308}
            or not location
            or not confined(location, target)
            or expected.path != target.base_path + "/"
        ):
            return False, "Bare prefix must redirect to its trailing-slash form"
        if routed_response is None or routed_response.status != 200:
            return False, "Routed page unavailable for prefix checks"
        if routed_response.header("location") and not confined(
            routed_response.header("location"), target
        ):
            return False, "Routed redirect escapes prefix"
        if "html" in routed_response.header("content-type").lower():
            parser = References()
            parser.feed(routed_response.body.decode("utf-8", errors="strict"))
            if len(parser.urls) > 128:
                return False, "HTML reference count exceeds probe bound"
            for tag, attribute, url in parser.urls:
                if url.startswith("#") or url.startswith("data:"):
                    continue
                if (
                    tag == "iframe"
                    and attribute == "src"
                    and navigation_document(url, target, manifest["app_id"])
                ):
                    continue
                if not confined(url, target):
                    return False, "HTML reference escapes the external prefix"
                parsed = urlsplit(
                    urljoin(target.routed_origin + target.base_path + "/", url)
                )
                response = request(
                    target.routed_origin,
                    parsed.path + ("?" + parsed.query if parsed.query else ""),
                    headers=dict(target.routed_headers),
                )
                if 300 <= response.status < 400 and not confined(
                    response.header("location"), target
                ):
                    return False, "Local reference redirects outside the prefix"
        return True, "Bare redirect and app references stay under the prefix"

    run("health", lambda: status(runtime["health_path"]))
    run("ready", ready)
    run("version", version)
    run("direct-context", missing)
    run("forged-context", forged)
    run("routed-access", routed)
    run("base-path", base_path)
    return CheckReport(
        __version__,
        1,
        "template" if template else "final",
        hashlib.sha256(raw).hexdigest(),
        tuple(findings),
    )
