import hashlib
import http.client
import json
import math
import os
import re
import tempfile
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass, field
from pathlib import Path
from typing import BinaryIO
from urllib.parse import parse_qs, quote, unquote, urlencode, urlsplit

from .errors import IntegrityError, PlatformError, ProtocolError, TransportError
from .models import (
    FileEntry,
    Input,
    Result,
    Run,
    Submission,
    User,
    VerifiedDownload,
    Workload,
    digest_value,
    integer_value,
    list_value,
    object_value,
    parse_run,
    text_value,
    uuid_value,
)

MAX_INPUT_BYTES = 20 * 1024**2
MAX_JSON_BYTES = 1024**2
CHUNK_BYTES = 64 * 1024


def _header(value: str) -> bool:
    return (
        isinstance(value, str)
        and 0 < len(value) <= 8192
        and all(32 <= ord(char) < 127 for char in value)
    )


def _json_object(pairs: list[tuple[str, object]]) -> dict[str, object]:
    result = dict(pairs)
    if len(result) != len(pairs):
        raise ProtocolError("Duplicate JSON field")
    return result


def _invalid_constant(_: str) -> object:
    raise ProtocolError("Nonfinite JSON number")


@dataclass(frozen=True)
class Platform:
    endpoint: str
    _credential: str = field(repr=False)
    timeout: float = 30
    max_download_bytes: int = 1024**3

    def __post_init__(self) -> None:
        try:
            url = urlsplit(self.endpoint)
            valid = (
                url.scheme in {"http", "https"}
                and url.hostname
                and url.port != 0
                and not url.username
                and not url.password
                and "@" not in url.netloc
                and not url.query
                and not url.fragment
                and url.path.rstrip("/") == "/api/apps/v1"
                and self.endpoint.isascii()
                and not any(ord(c) <= 32 or ord(c) == 127 for c in self.endpoint)
                and "\\" not in self.endpoint
            )
        except ValueError:
            valid = False
        if not valid:
            raise ValueError("Expected an HTTP(S) platform API URL without userinfo")
        if not _header(self._credential):
            raise ValueError("Invalid application credential")
        if not math.isfinite(self.timeout) or self.timeout <= 0:
            raise ValueError("Timeout must be positive and finite")
        if type(self.max_download_bytes) is not int or self.max_download_bytes <= 0:
            raise ValueError("Download limit must be a positive integer")
        object.__setattr__(self, "endpoint", self.endpoint.rstrip("/"))

    @classmethod
    def from_environment(cls) -> "Platform":
        try:
            endpoint = os.environ["PLATFORM_API_URL"]
            credential_file = Path(os.environ["APP_CREDENTIAL_FILE"])
            with credential_file.open("r", encoding="ascii") as source:
                credential = source.read(8193).strip()
            if len(credential) > 8192:
                raise ValueError
        except (KeyError, OSError, UnicodeError, ValueError):
            raise ValueError(
                "Platform endpoint and credential file are required"
            ) from None
        return cls(endpoint, credential)

    def for_request(self, assertion: str | None) -> "RequestClient":
        if assertion is None or not _header(assertion):
            raise ValueError("A gateway user context is required for each request")
        return RequestClient(self, assertion)


@dataclass(frozen=True, repr=False)
class RequestClient:
    _platform: Platform
    _assertion: str

    def __post_init__(self) -> None:
        if not _header(self._assertion):
            raise ValueError("A gateway user context is required for each request")

    def __enter__(self) -> "RequestClient":
        return self

    def __exit__(self, *_: object) -> None:
        pass

    @contextmanager
    def _response(
        self,
        method: str,
        path: str,
        *,
        body: bytes | BinaryIO | None = None,
        content_type: str | None = None,
        size: int | None = None,
        key: str | None = None,
    ) -> Iterator[http.client.HTTPResponse]:
        url = urlsplit(self._platform.endpoint)
        assert url.hostname is not None
        connection_type = (
            http.client.HTTPSConnection
            if url.scheme == "https"
            else http.client.HTTPConnection
        )
        connection = connection_type(
            url.hostname, url.port, timeout=self._platform.timeout
        )
        headers = {
            "Authorization": "Bearer " + self._platform._credential,
            "X-Platform-User-Context": self._assertion,
            "Accept": "application/json",
        }
        if content_type is not None:
            headers["Content-Type"] = content_type
        if size is not None:
            headers["Content-Length"] = str(size)
        if key is not None:
            headers["Idempotency-Key"] = key
        try:
            try:
                connection.request(method, path, body=body, headers=headers)
                response = connection.getresponse()
            except (OSError, http.client.HTTPException):
                raise TransportError(
                    "No complete platform response; replay only with saved intent"
                ) from None
            if 300 <= response.status < 400:
                raise ProtocolError("Platform redirects are refused")
            if response.status >= 400:
                raw = self._read(response, MAX_JSON_BYTES + 1)
                try:
                    value = json.loads(raw) if len(raw) <= MAX_JSON_BYTES else None
                    detail = value.get("detail") if isinstance(value, dict) else None
                except (ValueError, UnicodeError, RecursionError):
                    detail = None
                if not isinstance(detail, str):
                    detail = "Request refused"
                for secret in (self._platform._credential, self._assertion):
                    detail = detail.replace(secret, "[redacted]")
                detail = "".join(c if c.isprintable() else " " for c in detail)
                raise PlatformError(response.status, detail)
            yield response
        finally:
            connection.close()

    @staticmethod
    def _read(response: http.client.HTTPResponse, size: int) -> bytes:
        try:
            return response.read(size)
        except (OSError, http.client.HTTPException):
            raise TransportError("Platform response transfer failed") from None

    def _json(
        self,
        method: str,
        suffix: str,
        *,
        payload: object = None,
        statuses: tuple[int, ...] = (200,),
        key: str | None = None,
    ) -> dict[str, object]:
        body = (
            None
            if payload is None
            else json.dumps(
                payload, sort_keys=True, separators=(",", ":"), allow_nan=False
            ).encode()
        )
        with self._response(
            method,
            "/api/apps/v1" + suffix,
            body=body,
            content_type="application/json" if body is not None else None,
            key=key,
        ) as response:
            return self._read_json(response, statuses)

    @staticmethod
    def _read_json(
        response: http.client.HTTPResponse, statuses: tuple[int, ...]
    ) -> dict[str, object]:
        if response.status not in statuses:
            raise ProtocolError("Unexpected success status")
        if response.getheader("Content-Type", "").split(";")[0] != "application/json":
            raise ProtocolError("Expected application/json")
        raw = RequestClient._read(response, MAX_JSON_BYTES + 1)
        if len(raw) > MAX_JSON_BYTES:
            raise ProtocolError("JSON response exceeds the client limit")
        if response.length:
            raise TransportError("Platform JSON response was truncated")
        try:
            return object_value(
                json.loads(
                    raw,
                    object_pairs_hook=_json_object,
                    parse_constant=_invalid_constant,
                )
            )
        except (ValueError, UnicodeError, RecursionError):
            raise ProtocolError("Invalid JSON response") from None

    def current_user(self) -> User:
        item = self._json("GET", "/user")
        return User(uuid_value(item.get("id")), text_value(item.get("display_name")))

    def _workloads(self) -> tuple[tuple[Workload, ...], str | None]:
        payload = self._json("GET", "/workloads")
        active = payload.get("active_release_sha256")
        if active is not None:
            active = digest_value(active)
        items = []
        for raw in list_value(payload.get("items")):
            item = object_value(raw)
            names = tuple(text_value(n) for n in list_value(item.get("inputs")))
            if len(set(names)) != len(names):
                raise ProtocolError("Duplicate workload input name")
            items.append(
                Workload(
                    uuid_value(item.get("id")),
                    digest_value(item.get("release_sha256")),
                    text_value(item.get("workload_id")),
                    names,
                )
            )
        if len({item.installation_id for item in items}) != len(items):
            raise ProtocolError("Duplicate workload installation")
        return tuple(items), active

    def list_workloads(self) -> tuple[Workload, ...]:
        return self._workloads()[0]

    def workload(
        self, workload_id: str, *, release_sha256: str | None = None
    ) -> Workload:
        items, active = self._workloads()
        selected = (
            digest_value(release_sha256) if release_sha256 is not None else active
        )
        matches = [
            item
            for item in items
            if item.workload_id == workload_id
            and (selected is None or item.release_sha256 == selected)
        ]
        if len(matches) != 1:
            raise ProtocolError("Workload lookup needs one exact installation")
        return matches[0]

    @staticmethod
    def _input(item: dict[str, object], workload: Workload) -> Input:
        size = integer_value(item.get("size_bytes"))
        if not 0 < size <= MAX_INPUT_BYTES:
            raise ProtocolError("Input size is outside the API limit")
        return Input(
            uuid_value(item.get("id")),
            workload.installation_id,
            size,
            digest_value(item.get("sha256")),
        )

    def upload_input(self, workload: Workload, source: BinaryIO) -> Input:
        installation = uuid_value(workload.installation_id)
        digest = hashlib.sha256()
        size = 0
        with tempfile.TemporaryFile() as spool:
            while chunk := source.read(CHUNK_BYTES):
                size += len(chunk)
                if size > MAX_INPUT_BYTES:
                    raise ValueError("Input exceeds the 20 MiB limit")
                spool.write(chunk)
                digest.update(chunk)
            if size == 0:
                raise ValueError("Input cannot be empty")
            spool.seek(0)
            with self._response(
                "POST",
                f"/api/apps/v1/workloads/{installation}/uploads",
                body=spool,
                content_type="application/octet-stream",
                size=size,
            ) as response:
                item = self._input(self._read_json(response, (201,)), workload)
            if item.size_bytes != size or item.sha256 != digest.hexdigest():
                raise IntegrityError("Upload receipt does not match the sent bytes")
            return item

    def select_input(self, workload: Workload, path: str) -> Input:
        installation = uuid_value(workload.installation_id)
        item = self._json(
            "POST",
            f"/workloads/{installation}/file-handles",
            payload={"path": path},
            statuses=(201,),
        )
        return self._input(item, workload)

    def delete_input(self, source: Input) -> None:
        with self._response(
            "DELETE", "/api/apps/v1/inputs/" + uuid_value(source.id)
        ) as r:
            if r.status != 204:
                raise ProtocolError("Expected input deletion status 204")

    def browse_files(
        self, path: str = "Home", *, limit: int = 100, offset: int = 0
    ) -> tuple[FileEntry, ...]:
        query = self._page(limit, offset) + "&" + urlencode({"path": path})
        items = self._json("GET", "/files?" + query)
        entries = []
        for raw in list_value(items.get("items")):
            item = object_value(raw)
            kind = text_value(item.get("kind"))
            size = item.get("size_bytes")
            if kind == "file":
                size = integer_value(size)
            elif kind != "directory" or size is not None:
                raise ProtocolError("Invalid logical file entry")
            entries.append(
                FileEntry(
                    text_value(item.get("name")),
                    text_value(item.get("path")),
                    kind,
                    size,
                )
            )
        return tuple(entries)

    @staticmethod
    def _page(limit: int, offset: int) -> str:
        if type(limit) is not int or not 1 <= limit <= 100:
            raise ValueError("Page limit must be 1 to 100")
        if type(offset) is not int or not 0 <= offset <= 100000:
            raise ValueError("Page offset must be 0 to 100000")
        return urlencode({"limit": limit, "offset": offset})

    def submit_run(self, submission: Submission) -> Run:
        result = parse_run(
            self._json(
                "POST",
                "/runs",
                key=submission.key.value,
                statuses=(200, 201),
                payload={
                    "installation_id": submission.installation_id,
                    "inputs": dict(submission.inputs),
                },
            )
        )
        if result.installation_id != submission.installation_id:
            raise ProtocolError("Run receipt names a different installation")
        return result

    def get_run(self, run_id: str) -> Run:
        result = parse_run(self._json("GET", "/runs/" + uuid_value(run_id)))
        if result.id != run_id:
            raise ProtocolError("Run response names a different run")
        return result

    def list_runs(self, *, limit: int = 100, offset: int = 0) -> tuple[Run, ...]:
        item = self._json("GET", "/runs?" + self._page(limit, offset))
        return tuple(parse_run(raw) for raw in list_value(item.get("items")))

    def cancel_run(self, run_id: str) -> Run:
        result = parse_run(
            self._json("POST", "/runs/" + uuid_value(run_id) + "/cancel")
        )
        if result.id != run_id:
            raise ProtocolError("Cancellation response names a different run")
        return result

    def results(self, run_id: str) -> tuple[Result, ...]:
        item = self._json("GET", "/runs/" + uuid_value(run_id) + "/results")
        results = []
        for raw in list_value(item.get("outputs")):
            entry = object_value(raw)
            name = text_value(entry.get("name"))
            if name in {".", ".."} or any(c in name for c in "/\\\x00"):
                raise ProtocolError("Invalid result filename")
            results.append(
                Result(
                    integer_value(entry.get("index")),
                    name,
                    integer_value(entry.get("size_bytes")),
                    digest_value(entry.get("sha256")),
                    text_value(entry.get("download_url")),
                )
            )
        if len({(r.index, r.name) for r in results}) != len(results):
            raise ProtocolError("Duplicate result manifest entry")
        return tuple(results)

    def _download_path(self, run_id: str, result: Result) -> str:
        endpoint = urlsplit(self._platform.endpoint)
        address = result.download_url
        if not address.isascii() or re.search(r"[\x00-\x20\x7f\\]", address):
            raise ProtocolError("Unsafe result download URL")
        try:
            url = urlsplit(address)
            if url.scheme or url.netloc:
                origin = (
                    url.scheme,
                    url.hostname,
                    url.port or (443 if url.scheme == "https" else 80),
                )
                expected = (
                    endpoint.scheme,
                    endpoint.hostname,
                    endpoint.port or (443 if endpoint.scheme == "https" else 80),
                )
                if origin != expected or "@" in url.netloc:
                    raise ProtocolError("Result URL must use the platform origin")
            expected_path = (
                f"/api/apps/v1/runs/{run_id}/results/{result.index}/{result.name}"
            )
            if (
                unquote(url.path) != expected_path
                or url.fragment
                or parse_qs(url.query, strict_parsing=True)
                != {"sha256": [result.sha256]}
            ):
                raise ProtocolError("Result URL does not match its manifest entry")
        except ValueError:
            raise ProtocolError("Invalid result download URL") from None
        return (
            f"/api/apps/v1/runs/{run_id}/results/{result.index}/"
            + quote(result.name, safe="")
            + "?sha256="
            + result.sha256
        )

    def download_result(
        self, run_id: str, index: int, name: str, destination: str | Path
    ) -> VerifiedDownload:
        uuid_value(run_id)
        integer_value(index)
        matches = [
            r for r in self.results(run_id) if r.index == index and r.name == name
        ]
        if len(matches) != 1:
            raise ProtocolError("Requested result is absent from the manifest")
        result = matches[0]
        path = self._download_path(run_id, result)
        if result.size_bytes > self._platform.max_download_bytes:
            raise IntegrityError("Result exceeds the configured download limit")
        target = Path(destination)
        if target.exists() or target.is_symlink():
            raise FileExistsError("Download destination already exists")
        temporary: Path | None = None
        try:
            with tempfile.NamedTemporaryFile(
                dir=target.parent, prefix=".hp-download-", delete=False
            ) as output:
                temporary = Path(output.name)
                digest = hashlib.sha256()
                size = 0
                with self._response("GET", path) as response:
                    if (
                        response.status != 200
                        or response.getheader("Content-Type", "").split(";")[0]
                        != "application/octet-stream"
                    ):
                        raise ProtocolError("Expected a binary result response")
                    if (
                        response.length is not None
                        and response.length != result.size_bytes
                    ):
                        raise IntegrityError(
                            "Result length does not match the manifest"
                        )
                    while chunk := self._read(response, CHUNK_BYTES):
                        size += len(chunk)
                        if size > result.size_bytes:
                            raise IntegrityError("Result exceeds its declared size")
                        output.write(chunk)
                        digest.update(chunk)
                if size != result.size_bytes or digest.hexdigest() != result.sha256:
                    raise IntegrityError("Result bytes do not match the manifest")
                output.flush()
                os.fsync(output.fileno())
            os.link(temporary, target)
            return VerifiedDownload(target, run_id, index, name, size, result.sha256)
        finally:
            if temporary is not None:
                temporary.unlink(missing_ok=True)
