class PlatformError(Exception):
    """The platform returned an HTTP refusal with a bounded, redacted detail."""

    def __init__(self, status: int, detail: str) -> None:
        self.status = status
        self.detail = detail[:512]
        super().__init__(f"Platform HTTP {status}: {self.detail}")


class TransportError(Exception):
    """No complete response arrived; a mutation may already have happened."""


class ProtocolError(Exception):
    """The server response violates the versioned API contract."""


class IntegrityError(Exception):
    """Transferred bytes do not match the declared size and SHA-256."""
