import re
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from uuid import UUID, uuid4

from .errors import ProtocolError


def object_value(value: object) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ProtocolError("Expected a JSON object")
    return value


def text_value(value: object) -> str:
    if not isinstance(value, str) or not value:
        raise ProtocolError("Expected a nonempty string")
    return value


def uuid_value(value: object) -> str:
    result = text_value(value)
    try:
        if str(UUID(result)) != result:
            raise ValueError
    except ValueError:
        raise ProtocolError("Expected a canonical UUID") from None
    return result


def digest_value(value: object) -> str:
    result = text_value(value)
    if not re.fullmatch(r"[0-9a-f]{64}", result):
        raise ProtocolError("Expected a SHA-256 digest")
    return result


def integer_value(value: object) -> int:
    if type(value) is not int or value < 0:
        raise ProtocolError("Expected a nonnegative integer")
    return value


def list_value(value: object) -> list[Any]:
    if not isinstance(value, list):
        raise ProtocolError("Expected a JSON array")
    return value


@dataclass(frozen=True)
class User:
    id: str
    display_name: str


@dataclass(frozen=True)
class Workload:
    installation_id: str
    release_sha256: str
    workload_id: str
    inputs: tuple[str, ...]


@dataclass(frozen=True)
class Input:
    id: str
    installation_id: str
    size_bytes: int
    sha256: str


@dataclass(frozen=True)
class SubmissionKey:
    value: str

    def __post_init__(self) -> None:
        if not re.fullmatch(r"[A-Za-z0-9._:-]{1,128}", self.value):
            raise ValueError("Invalid submission key")

    @classmethod
    def new(cls) -> "SubmissionKey":
        return cls(str(uuid4()))


@dataclass(frozen=True)
class Submission:
    key: SubmissionKey
    installation_id: str
    inputs: tuple[tuple[str, str], ...]

    def __post_init__(self) -> None:
        uuid_value(self.installation_id)
        if not isinstance(self.inputs, tuple) or any(
            not isinstance(pair, tuple) or len(pair) != 2 for pair in self.inputs
        ):
            raise ValueError("Submission inputs must be immutable name-ID pairs")
        names = [text_value(name) for name, _ in self.inputs]
        if names != sorted(set(names)):
            raise ValueError("Submission inputs must have unique sorted names")
        for _, input_id in self.inputs:
            uuid_value(input_id)

    @classmethod
    def create(
        cls, *, key: SubmissionKey, workload: Workload, inputs: Mapping[str, Input]
    ) -> "Submission":
        if set(inputs) != set(workload.inputs):
            raise ValueError("Inputs must match the workload's declared names")
        if any(i.installation_id != workload.installation_id for i in inputs.values()):
            raise ValueError("Input belongs to a different workload installation")
        return cls(
            key,
            workload.installation_id,
            tuple(sorted((name, item.id) for name, item in inputs.items())),
        )

    def to_record(self) -> dict[str, object]:
        return {
            "key": self.key.value,
            "installation_id": self.installation_id,
            "inputs": dict(self.inputs),
        }

    @classmethod
    def from_record(cls, value: object) -> "Submission":
        record = object_value(value)
        if set(record) != {"key", "installation_id", "inputs"}:
            raise ProtocolError("Invalid saved submission fields")
        inputs = object_value(record["inputs"])
        return cls(
            SubmissionKey(text_value(record["key"])),
            uuid_value(record["installation_id"]),
            tuple(sorted((text_value(k), uuid_value(v)) for k, v in inputs.items())),
        )


@dataclass(frozen=True)
class Task:
    index: int
    status: str


@dataclass(frozen=True)
class Run:
    id: str
    installation_id: str
    status: str
    tasks: tuple[Task, ...]


@dataclass(frozen=True)
class FileEntry:
    name: str
    path: str
    kind: str
    size_bytes: int | None


@dataclass(frozen=True)
class Result:
    index: int
    name: str
    size_bytes: int
    sha256: str
    download_url: str


@dataclass(frozen=True)
class VerifiedDownload:
    path: Path
    run_id: str
    index: int
    name: str
    size_bytes: int
    sha256: str


def parse_run(value: object) -> Run:
    item = object_value(value)
    statuses = {"QUEUED", "RUNNING", "COMPLETED", "FAILED", "CANCELLED"}
    status = text_value(item.get("status"))
    tasks = []
    for raw in list_value(item.get("tasks")):
        task = object_value(raw)
        task_status = text_value(task.get("status"))
        if task_status not in statuses:
            raise ProtocolError("Unknown task status")
        tasks.append(Task(integer_value(task.get("index")), task_status))
    if status not in statuses or len({t.index for t in tasks}) != len(tasks):
        raise ProtocolError("Invalid run status or duplicate task index")
    return Run(
        uuid_value(item.get("id")),
        uuid_value(item.get("installation_id")),
        status,
        tuple(tasks),
    )
